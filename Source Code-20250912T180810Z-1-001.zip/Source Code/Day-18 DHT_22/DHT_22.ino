#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <dht_nonblocking.h>

#define UNIT_F 0
#define UNIT_C 1

#define dht_pin 4
#define update_interval 500
#define DHT_SENSOR_TYPE DHT_TYPE_22

LiquidCrystal_I2C lcd(0x27,16,2);  // set the LCD address to 0x27 for a 16 chars and 2 line display
DHT_nonblocking dht_sensor(dht_pin,DHT_SENSOR_TYPE);

void setup()
{
  LCD_SETUP();
}

void loop()
{
  Read_Sensor();
  
  static unsigned long timestamp;
  unsigned long now = millis();
  if(now>= timestamp + update_interval)
  {
    Read_Sensor( );
    timestamp = now;
  }
  
}

void LCD_TXT(float& tmp, bool temp_unit, float& hum)
{
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(String(tmp));
  lcd.print(char(223)); //degree
  switch(temp_unit)
  {
    case UNIT_C: lcd.print(F("C")); break;
    case UNIT_F: lcd.print(F("F")); break;
  }
  lcd.setCursor(0, 1);
  lcd.print(F("Humidity: "));
  lcd.print(String(hum));
  lcd.print(F("%"));
}

void LCD_SETUP()
{
  lcd.init();                      // initialize the lcd 
  lcd.backlight();
  lcd.clear();
}

inline void c2f(float & c, float & f)
{
  f= (c * 9 / 5) + 32;
}

//FROM LIBRARY-----------------------------------------------------------------
static bool measure_environment( float *temperature, float *humidity )
{
  static unsigned long measurement_timestamp = millis();
  /* Measure once every four seconds. */
  if( millis( ) - measurement_timestamp > update_interval)
  {
    if( dht_sensor.measure( temperature, humidity ) == true )
    {
      measurement_timestamp = millis( );
      return( true );
    }
  }
  return( false );
}

void Read_Sensor( )
{
  float temperature, humidity, f;
  if( measure_environment( &temperature, &humidity ) == true )
  {
    //c2f(temperature, f);
    LCD_TXT(temperature, UNIT_C, humidity);
  }
}